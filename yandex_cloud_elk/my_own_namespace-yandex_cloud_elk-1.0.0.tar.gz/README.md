## Ansible Collection - my_own_namespace.yandex_cloud_elk

- version: 1.0.0
- authors: Andrew Shestikhin
- repository: https://github.com/sisipka/my_own_collection


### Requirements
------------

On Ubuntu 20.04

### Role Variables
--------------

my_own_path: "tmp/test"
my_own_content: "Test is ok"