My_own_role
=========

Testing collections in Ansible.

Requirements
------------

On Ubuntu 20.04

Role Variables
--------------

my_own_path: "tmp/test"
my_own_content: "Test is ok"

Dependencies
------------

No

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: username.rolename, x: 42 }

License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
